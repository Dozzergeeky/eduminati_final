# eduminati
